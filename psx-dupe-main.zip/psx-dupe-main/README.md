# psx-dupe
# Working after bank patch!

![image](https://user-images.githubusercontent.com/101152799/164120198-54d15118-7e1f-42cc-acb0-41a4ff2488f0.png)

Preston tried to patch the duping 💀 but we wont stop until PSX is not P2W!

Bank: Tier 2-8.

Script: ```loadstring(game:HttpGet("https://raw.githubusercontent.com/PSXScriptsCZ/psx-dupe/main/dupe.lua"))()```
